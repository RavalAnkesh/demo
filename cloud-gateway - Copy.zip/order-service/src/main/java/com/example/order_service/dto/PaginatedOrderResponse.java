package com.example.order_service.dto;

import java.util.List;

public class PaginatedOrderResponse {
    private List<OrderResponseDTO> content;
    private int pageNumber;
    private int size;
    private int totalPages;
    private long totalElements;

    // Constructor
    public PaginatedOrderResponse(List<OrderResponseDTO> content, int pageNumber, int size, int totalPages, long totalElements) {
        this.content = content;
        this.pageNumber = pageNumber;
        this.size = size;
        this.totalPages = totalPages;
        this.totalElements = totalElements;
    }

    // Getters and Setters
    public List<OrderResponseDTO> getContent() { return content; }
    public void setContent(List<OrderResponseDTO> content) { this.content = content; }

    public int getPageNumber() { return pageNumber; }
    public void setPageNumber(int pageNumber) { this.pageNumber = pageNumber; }

    public int getSize() { return size; }
    public void setSize(int size) { this.size = size; }

    public int getTotalPages() { return totalPages; }
    public void setTotalPages(int totalPages) { this.totalPages = totalPages; }

    public long getTotalElements() { return totalElements; }
    public void setTotalElements(long totalElements) { this.totalElements = totalElements; }
}