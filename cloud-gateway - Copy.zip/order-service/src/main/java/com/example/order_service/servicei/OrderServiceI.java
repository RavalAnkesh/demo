package com.example.order_service.servicei;

import com.example.order_service.dto.OrderResponseDTO;
import com.example.order_service.entity.Order;
import org.springframework.data.domain.Page;

import java.util.List;

public interface OrderServiceI {
    Order placeOrUpdateOrder(Order order);
    List<OrderResponseDTO> getAllOrders();
    Order getOrderById(Long orderId);
    Page<OrderResponseDTO> searchByUserName(String userName, int page, int size);

    Page<OrderResponseDTO> searchByUserID(Long id, int page, int size);

    Page<OrderResponseDTO> searchByProductId(Long id, int page, int size);
    void cancelOrder(Long orderId);
}
