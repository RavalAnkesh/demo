package com.example.user_service.projection;

public interface UserProjection {
    Long getId();
    String getName();
}
