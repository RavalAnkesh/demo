package com.example.user_service.serviceimpl;

import com.example.user_service.entity.Employee;
import com.example.user_service.repository.EmployeeRepository;
import com.example.user_service.servicei.EmpServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmpServiceImpl implements EmpServiceI {
    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee create(Employee employee){
        return employeeRepository.save(employee);
    }

    public List<Employee> getAll() {
        return employeeRepository.findAll();
    }
    public Employee getById(Long id){
        return  employeeRepository.findById(id).orElse(null) ;
    }
    public Employee update(Long id,Employee employee){
        Employee exist = getById(id);
        if (exist == null){
            return null;
        }
//      Employee exist = employeeRepository.findById(id).orElse(null);
        exist.setName(employee.getName());
        exist.setCity(employee.getCity());
        return employeeRepository.save(exist);
    }
    public String  delete(Long id){
        if( ! employeeRepository.existsById(id)) {
            return null;
        }
        employeeRepository.deleteById(id);
        return "Employee ID : "+id+" Deleted Successful....";
    }
}