package com.example.user_service.repository;

import com.example.user_service.entity.User;
import com.example.user_service.projection.UserProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User,Long> {
    List<UserProjection> findAllProjectedBy();
}
