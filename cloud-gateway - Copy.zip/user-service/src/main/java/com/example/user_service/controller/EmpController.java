package com.example.user_service.controller;

import com.example.user_service.entity.Employee;
import com.example.user_service.servicei.EmpServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/emp")
public class EmpController {
    @Autowired
    private EmpServiceI empServicei;

    @PostMapping
    public ResponseEntity<Employee> createEmp(@RequestBody Employee employee){
        Employee emp =  empServicei.create(employee);
        return new ResponseEntity<>(emp,HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<?> getAll(){
        List<Employee> e = empServicei.getAll();
        if (e.isEmpty()){
            return new ResponseEntity<>("No EMPLOYEE Exist...",HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(e,HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id){
        Employee e= empServicei.getById(id);
        if (e == null){
            return new ResponseEntity<>("EMPLOYEE ID : "+id+" Not Found......",HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(e,HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public  ResponseEntity<?> update(@PathVariable Long id,@RequestBody Employee employee){
        Employee e = empServicei.update(id,employee);
        if(e == null){
            return new ResponseEntity<>("EMPLOYEE Id : "+id+" Not Found.....",HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(e,HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id){
        String s=empServicei.delete(id);
        if (s == null){
            return new ResponseEntity<>("EMPLOYEE Id : "+id+" Not Found..... ",HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>( s,HttpStatus.OK);
    }
}
