package com.example.user_service.servicei;

import com.example.user_service.entity.Employee;

import java.util.List;

public interface EmpServiceI {
    Employee create(Employee employee);
    List<Employee> getAll();
    Employee getById(Long id);
    Employee update (Long id,Employee employee);
    String delete(Long id);
}
